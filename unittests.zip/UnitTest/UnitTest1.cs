using bolnica;
using Microsoft.Data.Sqlite;


namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void test_correct_data_add()
        {
            Form1 f1 = new Form1();
            int count = 1;
            Form1.connection.Open();
            Form1.fio = "Test";
            Form1.dofb = "23.03.2000";
            Form1.num = "+9 (928) 214-50-23";
            Form1.gen = "�������";
            Form1.snils = "212-321-412-53";
            Form1.oms = "2132 1321 4325 3262";
 
            int result;
            try
            {
                f1.add_data();
                result = 1;
            }
            catch { result = 2; }
            Assert.AreEqual(count, result);
        }
        [TestMethod]
        public void Test_incorrect_data_add()
        {
            Form1 f1 = new Form1();
            int count = 1;
            Form1.connection.Open();
            Form1.fio = null;
            Form1.dofb = "23.03.2000";
            Form1.num = "+9 (928) 214-50-23";
            Form1.gen = "�������";
            Form1.snils = "212-321-412-53";
            Form1.oms = "2132 1321 4325 3262";

            int result;
            try
            {
                f1.add_data();
                result = 1;
            }
            catch { result = 2; }
            Assert.AreEqual(count, result);
        }
        [TestMethod]
        public void Test_correct_table_load_data()
        {
            Form1 f1 = new Form1();
            int count = 1;
            int result;
            try
            {
                f1.LoadData("SELECT * FROM uchet");
                result = 1;
            }
            catch { result = 2; }
            Assert.AreEqual(count, result);
        }
        [TestMethod]
        public void Test_incorrect_table_load_data()
        {
            Form1 f1 = new Form1();
            int count = 1;
            int result;
            try
            {
                f1.LoadData("SELECT * FROM test");
                result = 1;
            }
            catch { result = 2; }
            Assert.AreEqual(count, result);
        }
        [TestMethod]
        public void Test_correct_update_data()
        {
            Form1 f1 = new Form1();
            int count = 1;
            int result;
            Form1.connection.Open();
            Form1.idpolzovatelya = "2";
            Form1.fio = "TEST";
            Form1.dofb = "23.03.2000";
            Form1.num = "+9 (928) 214-50-23";
            Form1.gen = "�������";
            Form1.snils = "212-321-412-53";
            Form1.oms = "2132 1321 4325 3262";

            try
            {
                f1.update_data();
                result = 1;
            }
            catch { result = 2; }
            Assert.AreEqual(count, result);
        }
        [TestMethod]
        public void Test_incorrect_update_data()
        {
            Form1 f1 = new Form1();
            int count = 1;
            int result;
            Form1.connection.Open();
            Form1.idpolzovatelya = null;
            Form1.fio = "TEST";
            Form1.dofb = "23.03.2000";
            Form1.num = "+9 (928) 214-50-23";
            Form1.gen = "�������";
            Form1.snils = "212-321-412-53";
            Form1.oms = "2132 1321 4325 3262";

            try
            {
                f1.update_data();
                result = 1;
            }
            catch { result = 2; }
            Assert.AreEqual(count, result);
        }
        [TestMethod]
        public void Test_correct_delete_data()
        {
            Form1 f1 = new Form1();
            int count = 1;
            int result;
            Form1.connection.Open();
            Form1.idpolzovatelya = "1";

            try
            {
                f1.delete_data();
                result = 1;
            }
            catch { result = 2; }
            Assert.AreEqual(count, result);
        }
        [TestMethod]
        public void Test_incorrect_delete_data()
        {
            Form1 f1 = new Form1();
            int count = 1;
            int result;
            Form1.connection.Open();
            Form1.idpolzovatelya = null;

            try
            {
                f1.delete_data();
                result = 1;
            }
            catch { result = 2; }
            Assert.AreEqual(count, result);
        }
        [TestMethod]
        public void Test_add_passing_data()
        {
            Form4 f4 = new Form4();
            int count = 1;
            int result;
   
            try
            {
                f4.update_passing_data();
                result = 1;
            }
            catch { result = 2; }
            Assert.AreEqual(count, result);
        }
        [TestMethod]
        public void table_connection_test()
        {
            Form1 f1 = new Form1();
            int result, count = 1;
            string connectString = "Data Source=uchet.bd3";
            SqliteConnection connection = new SqliteConnection(connectString);
            SqliteCommand command = new SqliteCommand();
            
             try
            {
                connection.Open();
                result = 1;
            }
            catch { result = 2; }
            Assert.AreEqual(count, result);
        }
    }
}