﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bolnica
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }




      

        private void button1_Click(object sender, EventArgs e)
        {
         
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1.connection.Open();
            SqliteCommand command = new SqliteCommand();
            command.Connection = Form1.connection;
            command.CommandText = "SELECT count(*) FROM vrachi where Дата_прохождения BETWEEN'" + maskedTextBox1.Text + "'and '" + maskedTextBox2.Text + "' AND (Терапевт ='Прошел') AND (Офтальмолог ='Прошел')AND (Психиатр ='Прошел')AND (Нарколог ='Прошел')AND (Невролог ='Прошел')AND (Хирург ='Прошел')";
            command.ExecuteNonQuery();
            string? count = command.ExecuteScalar().ToString();
            command.CommandText = "SELECT uchet.ID, ФИО, Дата_прохождения FROM vrachi Join uchet on uchet.ID=vrachi.ID where Дата_прохождения >='" + maskedTextBox1.Text + "'and Дата_прохождения<='" + maskedTextBox2.Text + "' AND (Терапевт ='Прошел') AND (Офтальмолог ='Прошел')AND (Психиатр ='Прошел')AND (Нарколог ='Прошел')AND (Невролог ='Прошел')AND (Хирург ='Прошел')";
            command.ExecuteNonQuery();
            SqliteDataReader reader = command.ExecuteReader();
            string? colvo;

            colvo = "Количество пациентов,прошедших медицинские осмотры в период с " + maskedTextBox1.Text + " по " + maskedTextBox2.Text + " , равняется " + count.ToString() + "\n";
            colvo = colvo + "Список пациентов : " + "\n";
            while (reader.Read())
            {
                colvo = colvo + reader.GetString(0).ToString() + ", ";
                colvo = colvo + reader.GetString(1).ToString() + ", ";
                colvo = colvo + reader.GetString(2).ToString() + "\n";

            }
            var dialog = new SaveFileDialog();
            dialog.FileName = "Очет за период " + maskedTextBox1.Text + " - " + maskedTextBox2.Text;
            dialog.Filter = "Text files|*.txt|All Files|*.*";
            if (dialog.ShowDialog(this) == DialogResult.OK)
            File.WriteAllText(dialog.FileName, colvo );
        }
    }
}
