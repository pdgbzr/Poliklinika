﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bolnica
{
    public partial class Form4 : Form
    {
       

        public Form4()
        {
            
            InitializeComponent();
            fiobox.Text = Form1.fio;
            terapevtbox.Text = Form2.terapevt;
            oftalmologbox.Text = Form2.oftalmolog;
            psihiatrbox.Text = Form2.psihiatr;
            narkologbox.Text = Form2.narkolog;
            nevrologbox.Text = Form2.nevrolog;
            hirurgbox.Text = Form2.hirurg;
        }

        public void update_passing_data() {
            Form1.connection.Open();
            SqliteCommand command = new SqliteCommand();
            command.Connection = Form1.connection;
            command.CommandText = "UPDATE  vrachi set ФИО = '" + fiobox.Text + "', Терапевт = '" + terapevtbox.Text + "', Офтальмолог = '" + oftalmologbox.Text + "', Психиатр = '" + psihiatrbox.Text + "', Нарколог='" + narkologbox.Text + "',Невролог='" + nevrologbox.Text + "',Хирург='" + hirurgbox.Text + "' where ID = '" + Form1.idpolzovatelya + "'";
            int number = command.ExecuteNonQuery();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            update_passing_data();
        }
        private void fiobox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char l = e.KeyChar;
            if ((l < 'А' || l > 'я') && l != '\b')
            {
                e.Handled = true;
            }
        }
    }
}
