﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bolnica
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        Form1 form1;
        public Form5(Form1 owner)
        {
            form1 = owner;
            InitializeComponent();
    
        }
        public static int idz,izm;
        public static string datepass,rez;
        public static string name,status,result,data;
        private void button1_Click(object sender, EventArgs e)
        {
            SqliteCommand command = new SqliteCommand();
            command.Connection = Form1.connection;
            Form1.fio = fiobox.Text;
            Form1.dofb = datebirthbox.Text;
            Form1.num = numbox.Text;
            Form1.gen = polbox.Text;
            Form1.snils = snilsbox.Text;
            Form1.oms = omsbox.Text;
            form1.update_data();
        }
        public void LoadData(string query)
        {
            Form1.connection.Open();
            SqliteCommand command = new SqliteCommand(query, Form1.connection);
            SqliteDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            dataGridView1.Rows.Clear();
            while (reader.Read())
            {
                data.Add(new string[6]);

                data[data.Count - 1][0] = reader[5].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
                data[data.Count - 1][3] = reader[3].ToString();
                data[data.Count - 1][4] = reader[4].ToString();
            }
            reader.Close();
            Form1.connection.Close();
            foreach (string[] s in data)
                dataGridView1.Rows.Add(s);
            try
            {
                dataGridView1.Rows[0].Selected = false;
            }
            catch { };
        }
        private void Form5_Shown(object sender, EventArgs e)
        {
            idz = 0;
            if (Form1.sp == 1)
            {
                fiobox.ReadOnly = true;
                numbox.ReadOnly = true;
                polbox.Enabled = false;
                omsbox.ReadOnly = true;
                datebirthbox.ReadOnly = true;
                snilsbox.ReadOnly = true;
                button1.Visible = false;
            }
            fiobox.Text = Form1.fio;
            datebirthbox.Text = Form1.dofb;
            numbox.Text = Form1.num;
            polbox.Text = Form1.gen;
            snilsbox.Text = Form1.snils;
            omsbox.Text = Form1.oms;
            
            LoadData("SELECT * FROM vrachi_date where ID = '" + Form1.idpolzovatelya + "'");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            izm = 0;
            new Form7(this).Show();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            try

            {
                Form6.prichina = dataGridView1[2, e.RowIndex].Value?.ToString();
                Form6.kom = dataGridView1[3, e.RowIndex].Value?.ToString();
                idz = Convert.ToInt32(dataGridView1[0, e.RowIndex].Value);
                datepass= dataGridView1[1, e.RowIndex].Value?.ToString();
                rez = dataGridView1[4, e.RowIndex].Value?.ToString();

            }
            catch { }
        }

        private void fiobox_KeyUp(object sender, KeyEventArgs e)
        {

        }

        private void fiobox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (e.KeyChar == 39)
            {
                e.Handled = true;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            izm = 3;
            new Form7(this).Show();
        }


        private void button3_Click(object sender, EventArgs e)
        {
            
            izm = 1;
            if (idz == 0)
            {
                MessageBox.Show
               (
               "Выберите одну из ячеек перед изменением.",
               "Сообщение",
               MessageBoxButtons.OK,
               MessageBoxIcon.Information,
               MessageBoxDefaultButton.Button1
               ); ;

            }
            else
            {
                new Form7(this).Show();

            }
           

        }
        void Delete_data()
        {
            Form1.connection.Open();
            string sqlExpression = "DELETE FROM vrachi_date WHERE IDZ ='" + Form5.idz + "'";
            Form1.command = new SqliteCommand(sqlExpression, Form1.connection);
            Form1.command.ExecuteNonQuery();
        }
        private void button2_Click(object sender, EventArgs e)
        {

            try
            {
                Delete_data();
                LoadData("SELECT * FROM vrachi_date where ID = '" + Form1.idpolzovatelya + "'");
            }
            catch { };
        }
    }

}
