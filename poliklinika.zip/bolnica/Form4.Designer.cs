﻿namespace bolnica
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hirurgbox = new System.Windows.Forms.ComboBox();
            this.psihiatrbox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.nevrologbox = new System.Windows.Forms.ComboBox();
            this.narkologbox = new System.Windows.Forms.ComboBox();
            this.oftalmologbox = new System.Windows.Forms.ComboBox();
            this.terapevtbox = new System.Windows.Forms.ComboBox();
            this.fiobox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // hirurgbox
            // 
            this.hirurgbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.hirurgbox.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.hirurgbox.FormattingEnabled = true;
            this.hirurgbox.Items.AddRange(new object[] {
            "Прошел",
            "Не прошел"});
            this.hirurgbox.Location = new System.Drawing.Point(254, 324);
            this.hirurgbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.hirurgbox.Name = "hirurgbox";
            this.hirurgbox.Size = new System.Drawing.Size(265, 38);
            this.hirurgbox.TabIndex = 47;
            // 
            // psihiatrbox
            // 
            this.psihiatrbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.psihiatrbox.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.psihiatrbox.FormattingEnabled = true;
            this.psihiatrbox.Items.AddRange(new object[] {
            "Прошел",
            "Не прошел"});
            this.psihiatrbox.Location = new System.Drawing.Point(254, 180);
            this.psihiatrbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.psihiatrbox.Name = "psihiatrbox";
            this.psihiatrbox.Size = new System.Drawing.Size(265, 38);
            this.psihiatrbox.TabIndex = 46;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(153, 323);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 30);
            this.label6.TabIndex = 44;
            this.label6.Text = "Хирург";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(128, 277);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 30);
            this.label7.TabIndex = 43;
            this.label7.Text = "Невролог";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(129, 232);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 30);
            this.label8.TabIndex = 42;
            this.label8.Text = "Нарколог";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(136, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 30);
            this.label4.TabIndex = 41;
            this.label4.Text = "Психиатр";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(94, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(149, 30);
            this.label3.TabIndex = 40;
            this.label3.Text = "Офтальмолог";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(136, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 30);
            this.label2.TabIndex = 39;
            this.label2.Text = "Терапевт";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(175, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 30);
            this.label1.TabIndex = 38;
            this.label1.Text = "ФИО";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(153, 391);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(303, 60);
            this.button1.TabIndex = 36;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // nevrologbox
            // 
            this.nevrologbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.nevrologbox.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.nevrologbox.FormattingEnabled = true;
            this.nevrologbox.Items.AddRange(new object[] {
            "Прошел",
            "Не прошел"});
            this.nevrologbox.Location = new System.Drawing.Point(254, 273);
            this.nevrologbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nevrologbox.Name = "nevrologbox";
            this.nevrologbox.Size = new System.Drawing.Size(265, 38);
            this.nevrologbox.TabIndex = 48;
            // 
            // narkologbox
            // 
            this.narkologbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.narkologbox.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.narkologbox.FormattingEnabled = true;
            this.narkologbox.Items.AddRange(new object[] {
            "Прошел",
            "Не прошел"});
            this.narkologbox.Location = new System.Drawing.Point(254, 228);
            this.narkologbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.narkologbox.Name = "narkologbox";
            this.narkologbox.Size = new System.Drawing.Size(265, 38);
            this.narkologbox.TabIndex = 49;
            // 
            // oftalmologbox
            // 
            this.oftalmologbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.oftalmologbox.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.oftalmologbox.FormattingEnabled = true;
            this.oftalmologbox.Items.AddRange(new object[] {
            "Прошел",
            "Не прошел"});
            this.oftalmologbox.Location = new System.Drawing.Point(254, 131);
            this.oftalmologbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.oftalmologbox.Name = "oftalmologbox";
            this.oftalmologbox.Size = new System.Drawing.Size(265, 38);
            this.oftalmologbox.TabIndex = 50;
            // 
            // terapevtbox
            // 
            this.terapevtbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.terapevtbox.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.terapevtbox.FormattingEnabled = true;
            this.terapevtbox.Items.AddRange(new object[] {
            "Прошел",
            "Не прошел"});
            this.terapevtbox.Location = new System.Drawing.Point(254, 85);
            this.terapevtbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.terapevtbox.Name = "terapevtbox";
            this.terapevtbox.Size = new System.Drawing.Size(265, 38);
            this.terapevtbox.TabIndex = 51;
            // 
            // fiobox
            // 
            this.fiobox.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fiobox.Location = new System.Drawing.Point(253, 39);
            this.fiobox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fiobox.Name = "fiobox";
            this.fiobox.Size = new System.Drawing.Size(266, 36);
            this.fiobox.TabIndex = 52;
            this.fiobox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fiobox_KeyPress);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 495);
            this.Controls.Add(this.fiobox);
            this.Controls.Add(this.terapevtbox);
            this.Controls.Add(this.oftalmologbox);
            this.Controls.Add(this.narkologbox);
            this.Controls.Add(this.nevrologbox);
            this.Controls.Add(this.hirurgbox);
            this.Controls.Add(this.psihiatrbox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Список пройденных специалистов";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private ComboBox hirurgbox;
        private ComboBox psihiatrbox;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button button1;
        private ComboBox nevrologbox;
        private ComboBox narkologbox;
        private ComboBox oftalmologbox;
        private ComboBox terapevtbox;
        private TextBox fiobox;
    }
}